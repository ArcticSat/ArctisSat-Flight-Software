Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release v12.6 (Version 12.900.20.24)

Date    :    Wed Mar 24 10:16:32 2021
Project :    C:\Users\mites\Desktop\CDH-Phase-C-Tests\IrisSat-Flight-Software\iris-fsw-libero
